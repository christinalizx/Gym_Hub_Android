package edu.northeastern.gymhub.Utils;

public interface Callback {
    void onContinue();
    void onError();
}
