package edu.northeastern.gymhub.Views;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import edu.northeastern.gymhub.Models.ScheduleItem;
import edu.northeastern.gymhub.R;

public class ScheduleViewHolder extends RecyclerView.ViewHolder {
    private TextView itemNameTextView;
    private TextView itemTimeTextView;

    public ScheduleViewHolder(@NonNull View itemView) {
        super(itemView);
        itemNameTextView = itemView.findViewById(R.id.item_name);
        itemTimeTextView = itemView.findViewById(R.id.item_time);
    }

    public void bind(ScheduleItem scheduleItem) {
        itemNameTextView.setText(scheduleItem.getItemName());
        itemTimeTextView.setText(scheduleItem.getItemTime());
    }
}
